﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticalNo1All
{
    public partial class Employee : Form
    {
        Employee2 emp = null;
        public Employee()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            double bs = Convert.ToDouble(txtSal.Text);
            string id = txtId.Text;
            string name = txtName.Text;
            string de = txtDesig.Text;
            string dp = txtDep.Text;
            emp = new Employee2(bs,id,name,de,dp);
            lblOut.Text = emp.getName().ToString();
            MessageBox.Show("Total Salary is " + emp.Sal().ToString());
        }
    }

    class Employee2
    {
        double bs;
        string id;
        string name;
        string desig;
        string dept;
       public Employee2(double b, string emid, string nm, string ds, string dp)
        {
            bs = b;
            id = emid;
            name = nm;
            desig = ds;
            dept = dp;
        }

        public string getName()
        {
            return "ID: " + id +"\nName: " + name + "\nDesignation: " + desig + "\nDepartment: " + dept;
        }

        public double Sal()
        {
            return bs + ((bs * 0.80) + (bs * 0.10) - ((bs * 0.18) + 2400));
        }
    }
}
