﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticalNo1All
{
    public partial class Pract1Q5 : Form
    {
        public Pract1Q5()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            int a = Convert.ToInt32(txtLength.Text);
            int b = Convert.ToInt32(txtBreadth.Text);

            Add ad = new Add(a,b);
            Sub sb = new Sub(a,b);
            Multi ml = new Multi(a,b);
            Division dv = new Division(a,b);

            MessageBox.Show("Add:" + ad.sol() + ", Substract: " +sb.sol()+", Multiplication: " +ml.sol()+", Division: "+dv.sol());
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

    abstract class Calculation
    {
        public virtual int sol() {
            return 0;
        }
    }
    class Multi : Calculation
    {
        private int a;
        private int b;
        public Multi(int a, int b)
        {
            this.a = a;
            this.b = b;
        }
        public override int sol()
        {
            return a*b;
        }
    }

    class Division : Calculation
    {
        private int l;
        private int w;
        public Division(int a, int b)
        {
            l = a;
            w = b;
        }
        public override int sol()
        {
            return l/w;
        }
    }

    class Add : Calculation
    {
        private int l;
        private int w;
        public Add(int a, int b)
        {
            l = a;
            w = b;
        }
        public override int sol()
        {
            return l + w;
        }
    }

    class Sub : Calculation
    {
        private int l;
        private int w;
        public Sub(int a, int b)
        {
            l = a;
            w = b;
        }
        public override int sol()
        {
            return l - w;
        }
    }
}
