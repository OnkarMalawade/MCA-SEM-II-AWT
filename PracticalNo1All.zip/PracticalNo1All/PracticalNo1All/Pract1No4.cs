﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticalNo1All
{
    
    public partial class Pract1No4 : Form
    {
        
        public Pract1No4()
        {
            InitializeComponent();
        }

        private void baseClass_Click(object sender, EventArgs e)
        {
            double s1 = Convert.ToDouble(textBox1.Text);
            Shape2 s = new Shape2();
            MessageBox.Show("This is " + s.getArea(s1).ToString());
        }

        private void derClass_Click(object sender, EventArgs e)
        {
            double s1 = Convert.ToDouble(textBox1.Text);
            Shape2 s = new Shape2(s1);
            MessageBox.Show("This is " + s.AreaSqur().ToString());
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

    public interface circle
    {
        double getArea(double s);
    }
    public interface square
    {
       double AreaSqur();
    }

    class Shape2 : circle, square
    {
        double size;

        public Shape2(double size)
        {
            this.size = size;
        }

        public Shape2() { }

        public double getArea(double size)
        {
            this.size = size;
            return size * 3.14;
        }

        public double AreaSqur()
        {
            return size * size;
        }
    }

}
