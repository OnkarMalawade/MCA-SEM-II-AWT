﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticalNo1All
{
    public partial class Fibbo : Form
    {
        public Fibbo()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n = Convert.ToInt32(textBox1.Text);
            MessageBox.Show("Output : " + fibboNum(n));
        }

        public int fibboNum(int n) {
            if (n <= 1) {
                return n;
            }
            return (fibboNum(n - 1) + fibboNum(n - 2));
        }
    }
}
