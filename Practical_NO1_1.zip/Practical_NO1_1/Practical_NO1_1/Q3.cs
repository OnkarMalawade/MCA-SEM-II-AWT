﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practical_NO1_1
{
    public partial class Q3 : Form
    {
        public Q3()
        {
            InitializeComponent();
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            double knots;
            if (double.TryParse(knotT.Text, out knots))
            {
                WindSpeedConverter windConverter = new WindSpeedConverter(knots);
                mphLabel.Text = windConverter.ConvertToMph().ToString("0.00");
                kphLabel.Text = windConverter.ConvertToKph().ToString("0.00");
            }
            else
            {
                mphLabel.Text = "N/A";
                kphLabel.Text = "N/A";
                MessageBox.Show("Please enter a valid knots.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            knotT.Text = "";
            mphLabel.Text = "";
            kphLabel.Text = "";
        }
    }

    public class WindSpeedConverter
    {
        private double knots;

        public WindSpeedConverter(double knots)
        {
            this.knots = knots;
        }

        public double ConvertToMph()
        {
            return knots * 1.15078; // 1 knot = 1.15078 mph
        }

        public double ConvertToKph()
        {
            return knots * 1.852; // 1 knot = 1.852 kph
        }
    }
}
