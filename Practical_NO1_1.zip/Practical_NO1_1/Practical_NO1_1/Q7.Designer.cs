﻿
namespace Practical_NO1_1
{
    partial class Q7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.r1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.uC = new System.Windows.Forms.Button();
            this.s2 = new System.Windows.Forms.TextBox();
            this.s1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lC = new System.Windows.Forms.Button();
            this.concate = new System.Windows.Forms.Button();
            this.reverse = new System.Windows.Forms.Button();
            this.r2 = new System.Windows.Forms.Label();
            this.r3 = new System.Windows.Forms.Label();
            this.r4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // r1
            // 
            this.r1.AutoSize = true;
            this.r1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r1.Location = new System.Drawing.Point(547, 151);
            this.r1.Name = "r1";
            this.r1.Size = new System.Drawing.Size(101, 29);
            this.r1.TabIndex = 15;
            this.r1.Text = "Result1";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(175, 431);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(160, 43);
            this.button2.TabIndex = 14;
            this.button2.Text = "Clear";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // uC
            // 
            this.uC.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uC.Location = new System.Drawing.Point(50, 323);
            this.uC.Name = "uC";
            this.uC.Size = new System.Drawing.Size(163, 44);
            this.uC.TabIndex = 13;
            this.uC.Text = "UpperCase";
            this.uC.UseVisualStyleBackColor = true;
            this.uC.Click += new System.EventHandler(this.uC_Click);
            // 
            // s2
            // 
            this.s2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.s2.Location = new System.Drawing.Point(185, 227);
            this.s2.Name = "s2";
            this.s2.Size = new System.Drawing.Size(274, 34);
            this.s2.TabIndex = 12;
            // 
            // s1
            // 
            this.s1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.s1.Location = new System.Drawing.Point(185, 151);
            this.s1.Name = "s1";
            this.s1.Size = new System.Drawing.Size(274, 34);
            this.s1.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(50, 232);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 29);
            this.label3.TabIndex = 10;
            this.label3.Text = "String 2";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(50, 151);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 29);
            this.label2.TabIndex = 9;
            this.label2.Text = "String 1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(50, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(380, 46);
            this.label1.TabIndex = 8;
            this.label1.Text = "String Manipulation";
            // 
            // lC
            // 
            this.lC.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lC.Location = new System.Drawing.Point(50, 381);
            this.lC.Name = "lC";
            this.lC.Size = new System.Drawing.Size(160, 44);
            this.lC.TabIndex = 16;
            this.lC.Text = "LowerCase";
            this.lC.UseVisualStyleBackColor = true;
            this.lC.Click += new System.EventHandler(this.lC_Click);
            // 
            // concate
            // 
            this.concate.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.concate.Location = new System.Drawing.Point(299, 323);
            this.concate.Name = "concate";
            this.concate.Size = new System.Drawing.Size(163, 43);
            this.concate.TabIndex = 17;
            this.concate.Text = "Concate";
            this.concate.UseVisualStyleBackColor = true;
            this.concate.Click += new System.EventHandler(this.concate_Click);
            // 
            // reverse
            // 
            this.reverse.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reverse.Location = new System.Drawing.Point(299, 382);
            this.reverse.Name = "reverse";
            this.reverse.Size = new System.Drawing.Size(163, 43);
            this.reverse.TabIndex = 18;
            this.reverse.Text = "Reverse";
            this.reverse.UseVisualStyleBackColor = true;
            this.reverse.Click += new System.EventHandler(this.reverse_Click);
            // 
            // r2
            // 
            this.r2.AutoSize = true;
            this.r2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r2.Location = new System.Drawing.Point(547, 230);
            this.r2.Name = "r2";
            this.r2.Size = new System.Drawing.Size(101, 29);
            this.r2.TabIndex = 19;
            this.r2.Text = "Result2";
            // 
            // r3
            // 
            this.r3.AutoSize = true;
            this.r3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r3.Location = new System.Drawing.Point(547, 323);
            this.r3.Name = "r3";
            this.r3.Size = new System.Drawing.Size(101, 29);
            this.r3.TabIndex = 20;
            this.r3.Text = "Result3";
            // 
            // r4
            // 
            this.r4.AutoSize = true;
            this.r4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.r4.Location = new System.Drawing.Point(547, 389);
            this.r4.Name = "r4";
            this.r4.Size = new System.Drawing.Size(101, 29);
            this.r4.TabIndex = 21;
            this.r4.Text = "Result4";
            // 
            // Q7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1079, 515);
            this.Controls.Add(this.r4);
            this.Controls.Add(this.r3);
            this.Controls.Add(this.r2);
            this.Controls.Add(this.reverse);
            this.Controls.Add(this.concate);
            this.Controls.Add(this.lC);
            this.Controls.Add(this.r1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.uC);
            this.Controls.Add(this.s2);
            this.Controls.Add(this.s1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Q7";
            this.Text = "Q7";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label r1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button uC;
        private System.Windows.Forms.TextBox s2;
        private System.Windows.Forms.TextBox s1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button lC;
        private System.Windows.Forms.Button concate;
        private System.Windows.Forms.Button reverse;
        private System.Windows.Forms.Label r2;
        private System.Windows.Forms.Label r3;
        private System.Windows.Forms.Label r4;
    }
}