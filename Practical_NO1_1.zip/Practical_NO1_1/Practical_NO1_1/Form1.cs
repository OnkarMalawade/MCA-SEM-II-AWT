﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practical_NO1_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnPhoto_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.Filter = "Image Files (*.jpg; *.jpeg; *.png; *.gif; *.bmp)|*.jpg; *.jpeg; *.png; *.gif; *.bmp";

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    string imageLocation = dialog.FileName;               
                    picImg.Image = Image.FromFile(imageLocation);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string fname = FName.Text;
            string mname = MName.Text;
            string lname = LName.Text;
            DateTime dob = DoB.Value;
            string addr = address.Text;
            string mobile = MNo.Text;
            string gender = "";
            if (male.Checked)
            {
                gender = "Male";
            }
            else if (female.Checked)
            {
                gender = "Female";
            }
            else
            {
                gender = "Other";
            }
            string hobbies = Hobbies.Text;
            string City = city.SelectedItem?.ToString();

            string uname = uName.Text;
            string pwd = Password.Text;
            Image image = picImg.Image;


            Form2 form = new Form2(fname, mname, lname, dob, addr, mobile, gender, hobbies, City, uname, pwd,image);
            form.Show();

           
            this.Hide();
        }

        
    }

}
