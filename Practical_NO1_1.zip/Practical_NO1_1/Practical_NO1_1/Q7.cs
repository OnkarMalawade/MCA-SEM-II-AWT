﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practical_NO1_1
{
    public partial class Q7 : Form
    {
        public Q7()
        {
            InitializeComponent();
        }

        private void uC_Click(object sender, EventArgs e)
        {
            string str1 = s1.Text.ToUpper();
            string str2 = s2.Text.ToUpper();
            r1.Text = str1;
            r2.Text = str2;
        }

        private void lC_Click(object sender, EventArgs e)
        {
            string str1 = s1.Text.ToLower();
            string str2 = s2.Text.ToLower();
           
            r1.Text = str1;
            r2.Text = str2;
        }

        private void concate_Click(object sender, EventArgs e)
        {
            string str1 = s1.Text;
            string str2 = s2.Text;
            r3.Text ="Concate String Is: "+ str1 + " " + str2;
        }

        private void reverse_Click(object sender, EventArgs e)
        {
            string str1 = s1.Text;
            string reversed = new string(str1.Reverse().ToArray());
            r4.Text = "Reversed string 1: " + reversed;
        }
    }
}
