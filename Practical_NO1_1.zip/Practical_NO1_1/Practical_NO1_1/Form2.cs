﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practical_NO1_1
{
    
    public partial class Form2 : Form
    {
        public Form2(string fname, string mname, string lname, DateTime dob, string addr, string mobile, string gender, string hobbies, string city, string uname, string pwd , Image image)
        {
            InitializeComponent();
            fnm.Text = $"{fname} {mname} {lname}";
            date.Text = dob.ToShortDateString();
            adr.Text = addr;
            Mobile.Text = mobile;
            gen.Text = gender;
            hob.Text = hobbies;
            Lcity.Text = city;
            unm.Text = uname;
            lpwd.Text = pwd;
            PicBox.Image = image;
        }

      /*  private void Form2_Load(object sender,EventArgs e)
        {
            fnm.Text = Name;
        }*/
        
    }
}
