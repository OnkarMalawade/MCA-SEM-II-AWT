﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practical_NO1_1
{
    public partial class Q2 : Form
    {
        public Q2()
        {
            InitializeComponent();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            resultLabel.Text = "";
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            if (int.TryParse(YearT.Text, out int year))
            {
                bool y = IsLeapYear(year);
                resultLabel.Text = $"{year} {(y ? "is" : "is not")} a leap year.";
            }
            else
            {
                resultLabel.Text = "Please enter a valid year";
            }
        }

        private bool IsLeapYear(int year)
        {
            return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
        }
    }
}
