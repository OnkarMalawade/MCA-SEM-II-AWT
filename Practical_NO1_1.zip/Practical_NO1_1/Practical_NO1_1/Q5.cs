﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practical_NO1_1
{
    public partial class Q5 : Form
    {
        Rectangle rectangle = null;
        public Q5()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            len.Text = "";
            width.Text = "";
            Result.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int l = Convert.ToInt32(len.Text);
            int w = Convert.ToInt32(width.Text);
            if (w == 0)
            {
                rectangle = new Rectangle(l, l);
                Result.Text = "Area of Rectangle is "+rectangle.Area().ToString();
            }
            else
            {
                rectangle = new Rectangle(l, w);
                Result.Text = "Area of Rectangle is " + rectangle.Area().ToString();
                
            }
        }

        abstract class Shape
        {
            public abstract int Area();
        }
        class Rectangle : Shape
        {
            private int length;
            private int width;
            public Rectangle(int l, int w)
            {
                length = l;
                width = w;
            }
            public override int Area()
            {
                return length * width;
            }
        }
    }
}
